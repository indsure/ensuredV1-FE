import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function DashboardPage() {
  return (
    <AppShell role="admin">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardHeader><CardTitle>Total Policies</CardTitle></CardHeader><CardContent className="text-2xl font-bold">1,204</CardContent></Card></Card>
          <Card><CardHeader><CardTitle>Active Agents</CardTitle></CardHeader><CardContent className="text-2xl font-bold">24</CardContent></Card></Card>
          <Card><CardHeader><CardTitle>Pending Queue</CardTitle></CardHeader><CardContent className="text-2xl font-bold">56</CardContent></Card></Card>
          <Card><CardHeader><CardTitle>Success Rate</CardTitle></CardHeader><CardContent className="text-2xl font-bold">98.2%</CardContent></Card></Card>
        </div>
        
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader><CardTitle>Recent Failures</CardTitle></CardHeader>
            <CardContent>
              <table className="w-full text-sm">
                <thead><tr className="border-b text-left"><th className="pb-2">Policy</th><th className="pb-2">Error</th><th className="pb-2">Actions</th></tr></thead>
                <tbody>
                  <tr className="border-b"><td className="py-2">POL-001</td><td className="text-destructive">OCR Failed</td><td><button className="text-primary hover:underline">Retry</button></td></tr>
                </tbody>
              </table>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader><CardTitle>High Risk Items</CardTitle></CardHeader>
            <CardContent>
              <table className="w-full text-sm">
                <thead><tr className="border-b text-left"><th className="pb-2">ID</th><th className="pb-2">Score</th><th className="pb-2">Actions</th></tr></thead>
                <tbody>
                  <tr className="border-b"><td className="py-2">POL-002</td><td className="text-orange-500">42/100</td><td><button className="text-primary hover:underline">View</button></td></tr>
                </tbody>
              </table>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
