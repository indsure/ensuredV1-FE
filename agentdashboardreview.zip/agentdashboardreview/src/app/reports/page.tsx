import { AppShell } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
export default function ReportsPage() {
  return (
    <AppShell role="admin">
      <h1 className="text-3xl font-bold mb-6">Reports</h1>
      <Card>
        <div className="p-6">Reports Table Placeholder</div>
      </Card>
    </AppShell>
  );
}
